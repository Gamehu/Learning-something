package dubbo.web.client;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import ibusiness.IBusinessOrder;
import model.OrderInfo;
public class HessianConsumer {

	public static void main(String[] args) throws Throwable {		
		
	    ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"applicationContext.xml"});	

	       context.start();
	       IBusinessOrder demoWebService = (IBusinessOrder)context.getBean("demoService"); //
	       String a= demoWebService.SendStr("hello");

	       System.out.println("Output --- :  "+a);
	       
	       
	       OrderInfo o =new OrderInfo();
	       
	       o.setCount(5);
	       o.setCustomerID(123456l);
	       
	       OrderInfo o2=demoWebService.LoadOrder(o);
	       
	       System.out.println("Output --- :  "+o2.getCount());
	       
	       context.close();
	}

	
	
}

 