package ibusiness;

import ibusiness.IBusinessOrder;
 
import java.util.List;

import model.*;

public class BusinessOrder implements IBusinessOrder {
    public String SendStr(String str) {
    	
    	System.out.println("receive:"+str);
        return str;
    }

     public List<OrderInfo> LoadOrders(List<OrderInfo> orders) {
        return orders;
     }
 
    public OrderInfo LoadOrder(OrderInfo order) {
         return order;
    }
 }
