package web;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.ContextLoader;

public class DemoContextLoader extends ContextLoader implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		String config = arg0.getServletContext().getInitParameter("contextConfigLocation");
		System.out.println(config);
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(config);
		context.start();
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		
	}

}