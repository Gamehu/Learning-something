package ibusiness;

import java.util.List;

import model.*;

public interface IBusinessOrder { 
    public String SendStr(String str); 

    public List<OrderInfo> LoadOrders(List<OrderInfo> orders); 
 
    public OrderInfo LoadOrder(OrderInfo order);
 }