package model;

import java.io.Serializable;
import java.util.List;

public class OrderInfo implements Serializable {
	
	Long orderID;
	int count;
	Long customerID;
	String orderAddress;
	String userName;
	String email;
	List<OrderInfo> subOrderIDs;
	
	public Long getOrderID() {
		return orderID;
	}
	public void setOrderID(Long orderID) {
		this.orderID = orderID;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public Long getCustomerID() {
		return customerID;
	}
	public void setCustomerID(Long customerID) {
		this.customerID = customerID;
	}
	public String getOrderAddress() {
		return orderAddress;
	}
	public void setOrderAddress(String orderAddress) {
		this.orderAddress = orderAddress;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<OrderInfo> getSubOrderIDs() {
		return subOrderIDs;
	}
	public void setSubOrderIDs(List<OrderInfo> subOrderIDs) {
		this.subOrderIDs = subOrderIDs;
	}

	
	
	
}
