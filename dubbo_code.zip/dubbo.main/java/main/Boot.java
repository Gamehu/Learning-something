package main;

import java.io.IOException;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Boot {

	public static void main(String[] args) throws IOException {
//		ClassPathXmlApplicationContext context;
//			context = new ClassPathXmlApplicationContext("provider.xml");
//			context.start();
//			context.registerShutdownHook();
//			System.in.read();
        com.alibaba.dubbo.container.Main.main(args);
	       
	}

}
